package com.tango.metallica.trade.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.tango.metallica.trade.enitity.Role;

public interface RoleRepo extends JpaRepository<Role, Integer> {

}
