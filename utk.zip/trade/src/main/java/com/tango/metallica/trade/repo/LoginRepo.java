package com.tango.metallica.trade.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tango.metallica.trade.enitity.Login;

public interface LoginRepo extends JpaRepository<Login, Integer>{

}
